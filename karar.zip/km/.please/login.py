import os 
os.system('clear')

print("[+] SETUP LOGIN")
h = "\033[92m"
p = "\033[0m"
a = str(input('[?] input username: '))
b = str(input('[?] input password: '))
print("\n[+] set username to: " + h + a + p)
print("[+] set password to: " + h + b + p + "\n")
c = str(input('[+] input "yes" to confirm: '))
if c == "yes":
	pass
else:
	print("[+] failed!")
	exit()

#gas
file = open('file.txt').read()
open ('data.txt', 'w').write(a + "\n" + b)
open ('.home', 'w').write(file)

print("[+] success, please restart your Termux")
